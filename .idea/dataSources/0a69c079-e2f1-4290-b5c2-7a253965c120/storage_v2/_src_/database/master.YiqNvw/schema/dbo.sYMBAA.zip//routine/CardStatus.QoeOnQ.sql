
CREATE PROCEDURE CardStatus @num int, @pin int, @status int OUTPUT AS
BEGIN
SET NOCOUNT ON;
DECLARE @validInfo INT;
SELECT @validInfo = COUNT(*) from Card
where cardNum=@num and PIN = @pin;
IF(@validInfo>0)
    SET @status = 1;
ELSE
    SET @status = 0;
END
go

