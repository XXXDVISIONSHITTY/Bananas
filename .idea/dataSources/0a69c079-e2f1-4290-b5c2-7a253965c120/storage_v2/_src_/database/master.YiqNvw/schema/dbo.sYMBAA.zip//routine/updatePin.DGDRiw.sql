CREATE PROCEDURE updatePin
    @num VARCHAR(4),
    @oldPin VARCHAR(4),
    @newPin VARCHAR(4)
AS
BEGIN
    IF (LEN(@num) <> 4 or LEN(@oldPin) <> 4 or LEN(@newPin) <> 4)
    BEGIN
        PRINT 'Error: Invalid input.'
        RETURN
    END

    DECLARE @currentPin VARCHAR(4)
    SELECT @currentPin = pin
    FROM Card
    WHERE cardNumber = @num

    IF (@currentPin IS NULL)
    BEGIN
        PRINT 'Error: Invalid Card number.'
        RETURN
    END

    IF (@currentPin <> @oldPin)
    BEGIN
        PRINT 'Error: Old PIN does not match.'
        RETURN
    END

    UPDATE cardInfo
    SET pin = @newPin
    WHERE cardNumber = @num

    IF @@ROWCOUNT > 0
    BEGIN
        PRINT 'Updated PIN'
    END
    ELSE
    BEGIN
        PRINT 'Error occured.'
    END
END

EXEC updatePin '1234', '1234', '5678';
go

